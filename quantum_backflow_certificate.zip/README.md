# Two-interval quantum backflow certificate

## AI work disclosure

Lyra, an AI assistant powered by OpenAI, performed the literature search, calculations, code development, computational checks and writing. Daniel A. Pyle initiated the project, requested verification and reviewed the write-up. He is an uncredentialed independent researcher. The checks and audits were also AI-conducted; there has been no outside human specialist review. This is not official OpenAI research or an endorsement by OpenAI.

This package contains an explicit normalized positive-momentum state and an executable certificate that its summed backflow over two intervals is greater than 0.06190, under the arithmetic assumptions in certificate/PROOF.md.

Read quantum_backflow_research_note.docx for the plain-language result. This is a lower bound at a specified geometry, not an optimum or a claim of established publication priority. The calculations, code, write-up and audits were AI-generated or AI-assisted and checked through computational reruns. No outside human specialist review has taken place. This is revised version 2.

## Verify the result

From this extracted directory:

    sh certificate/run.sh

Requirements: Linux x86-64; gcc; MPFR shared library libmpfr.so.6; Python with NumPy, SciPy and mpmath. No network is required when these dependencies are installed. The script compiles the included C source with fast-math and floating-point contraction disabled. The original tested run took about 103 seconds; subsequent runs took about two minutes. RAM use was not measured. The verifier checks arithmetic settings and prints/writes an interval whose lower endpoint must exceed 0.06190.

A separate rebuild/rerun can be reproduced with:

    sh certificate/run_independent.sh

That uses the same mathematical certificate algorithm and is not a second independent proof method. Its earlier results and AI-assisted scientific audit are included. Both entrypoints enforce the expected archive hash before computation; the hash test checks their guard and mathematical parity.

## State and certificate

explicit_state_L320_g1.5.npz contains binary-exact coefficients defining the state; explicit_state_metadata.json specifies the exact squared norm. The verifier recomputes that norm and checks the coefficient archive SHA256. No eigensolver is part of the certificate. See certificate/PROOF.md for interval quadrature, the custom FFT rounding bound and arithmetic trust assumptions. mixed_panel_certificate_bound.md proves the integration remainder used by the verifier.

Expected final enclosure: approximately [0.06195510650587079, 0.06195512654165395]. The conservative result is R > 0.06190. These are dimensionless summed probability differences over [-1.75,-0.75] and [0.75,1.75], with hbar=1 and mass=1/2.

## Earlier numerical work

numerics/ contains exploration scripts and JSON records. To re-evaluate the fixed coefficient state with the exploratory FFT solver, run from this directory:

    python -c "import sys;sys.path.insert(0,'numerics');from fft_solver import solve;solve(L=320,g=1.5,k=24,nh=64,lift_path='explicit_state_L320_g1.5.npz')"

The exploratory solver uses ordinary floating point and is not the certificate. Its high-order versions can need several GB of memory. history/REPORT_v1_numerical_only.md preserves the earlier pre-certification record and its then-current limitations; the present report and certificate supersede its status. That historical report references additional intermediate files not needed by this package.

## References and scope

Fewster and Kirk-Karakaya, Repeated quantum backflow and overflow, Proceedings of the Royal Society A 481 (2025), 20250577, published Table 2: https://doi.org/10.1098/rspa.2025.0577

Kirk-Karakaya, The Quantum Backflow Phenomenon, thesis, Table 3.5: https://etheses.whiterose.ac.uk/id/eprint/38105/8/Kirk-Karakaya_203026398_CorrectedThesisClean2.pdf

Original authors' code and data: https://github.com/hkk506/Repeated-quantum-backflow-and-quantum-overflow/

The original framework/code already supports arbitrary interval timing; see code/MB_matrix_elementsArbToMaple.py in the linked repository. This package does not claim that capability as a contribution. External dependency binaries and the authors' reference repository are not bundled.

SHA256SUMS covers all packaged files except itself. certificate/MANIFEST.sha256 covers the core scientific certificate files relative to this directory.
