from fft_solver import solve,ROOT
for k in [24,48]:
 solve(L=320,g=1.5,k=k,nh=64,lift_path=ROOT.parent/'explicit_state_L320_g1.5.npz')
