from scipy.optimize import minimize_scalar
from fft_solver import solve,ROOT
import json
out=[]
for L in [40,80,320]:
 result=minimize_scalar(lambda g:-solve(L=L,g=float(g),k=8)['lambda_max'],bounds=(1.3,1.7),method='bounded',options={'xatol':1e-4,'maxiter':14})
 out.append(dict(L=L,gap=float(result.x),lambda_max=float(-result.fun),nfev=result.nfev,success=bool(result.success)))
 print('OPTIMUM',out[-1],flush=True)
(ROOT/'gap_optima.json').write_text(json.dumps(out,indent=2))
