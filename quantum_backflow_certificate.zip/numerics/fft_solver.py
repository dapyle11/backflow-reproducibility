import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import numpy as np,time,json
from scipy.special import roots_legendre
from scipy.fft import rfft,irfft,next_fast_len
from scipy.sparse.linalg import LinearOperator,eigsh
from pathlib import Path
ROOT=Path(__file__).parent

def solve(L=40,g=1.5,h=2.,k=8,nh=32,save=False,lift_path=None):
 t0=time.perf_counter();m=int(round(L*L/h))-1;L=np.sqrt((m+1)*h)
 z,w=roots_legendre(k);off=(z+1)*h/2;ww=w*h/2
 x=h*np.arange(1,m+1)[None,:]+off[:,None]
 p=np.sqrt(x);wx=np.broadcast_to(ww[:,None],x.shape);wp=wx/(2*p)
 a=np.sqrt(wx)*x**.25;b=np.sqrt(wx)*x**(-.25)
 z,wh=roots_legendre(nh);ph=(z+1)*np.sqrt(h)/2;wh=wh*np.sqrt(h)/2
 def kp(p,q):
  S=p+q;E=(p-q)*S
  return -S/np.pi*np.sinc(E/(2*np.pi))*np.cos((g+1)*E/2)
 H=kp(ph[:,None],ph[None,:])*np.sqrt(wh[:,None]*wh[None,:])
 C=np.empty((nh,k*m))
 for start in range(0,k*m,8192):
  stop=min(start+8192,k*m)
  C[:,start:stop]=kp(ph[:,None],p.ravel()[None,start:stop])*np.sqrt(wh[:,None]*wp.ravel()[None,start:stop])
 nfft=next_fast_len(2*m)
 ff=np.empty((k,k,nfft//2+1),complex)
 for r in range(k):
  for s in range(k):
   d=off[r]-off[s]
   z1=h*np.arange(m)+d;z2=-h*np.arange(1,m)+d
   co=-np.sinc(z1/(2*np.pi))*np.cos((g+1)*z1/2)/(2*np.pi)
   ro=-np.sinc(z2/(2*np.pi))*np.cos((g+1)*z2/2)/(2*np.pi)
   emb=np.zeros(nfft);emb[:m]=co;emb[-m+1:]=ro[::-1]
   ff[r,s]=rfft(emb)
 def conv(v):
  vf=rfft(v,nfft,axis=1)
  return irfft(np.einsum('rsf,sf->rf',ff,vf,optimize=True),nfft,axis=1)[:,:m]
 calls=0
 def mv(v):
  nonlocal calls;calls+=1
  vh=v[:nh];vt=v[nh:].reshape(k,m)
  tail=a*conv(b*vt)+b*conv(a*vt)+(C.T@vh).reshape(k,m)
  return np.r_[H@vh+C@vt.ravel(),tail.ravel()]
 n=nh+k*m;op=LinearOperator((n,n),matvec=mv,dtype=float)
 if lift_path is None:
  lam,v=eigsh(op,k=1,which='LA',tol=1e-11,v0=np.ones(n),maxiter=500)
 else:
  from scipy.interpolate import BarycentricInterpolator
  old=np.load(lift_path)
  if 'head_coeff' in old:
   from scipy.special import eval_legendre
   ko=int(old['k']);no=int(old['nh']);znew,_=roots_legendre(k);znh,_=roots_legendre(nh)
   P=np.array([eval_legendre(l,znew) for l in range(ko)]).T
   tail=(P@(np.sqrt((2*np.arange(ko)+1)/h)[:,None]*old['tail_coeff']))*np.sqrt(ww[:,None])
   Ph=np.array([eval_legendre(l,znh) for l in range(no)]).T
   head=(Ph@(np.sqrt((2*np.arange(no)+1)/np.sqrt(h))*old['head_coeff']))*np.sqrt(wh)
   vv=np.r_[head,tail.ravel()]/np.sqrt(float(old['norm2']));norm=np.linalg.norm(vv)
  else:
   ko=int(old['k']);no=int(old['nh']);vo=old['v'];zo,wo=roots_legendre(ko);wo=wo*h/2
   znew,_=roots_legendre(k);B=BarycentricInterpolator(zo,np.eye(ko))(znew)
   tail=(B@(vo[no:].reshape(ko,m)/np.sqrt(wo[:,None])))*np.sqrt(ww[:,None])
   zoh,woh=roots_legendre(no);woh=woh*np.sqrt(h)/2;znh,wnh=roots_legendre(nh);wnh=wnh*np.sqrt(h)/2
   Bh=BarycentricInterpolator(zoh,np.eye(no))(znh)
   head=(Bh@(vo[:no]/np.sqrt(woh)))*np.sqrt(wnh)
   vv=np.r_[head,tail.ravel()];norm=np.linalg.norm(vv);vv/=norm
  lam=np.array([vv@mv(vv)]);v=vv[:,None]

 residual=np.linalg.norm(mv(v[:,0])-lam[0]*v[:,0])
 rec=dict(L=float(L),g=g,h=h,k=k,nh=nh,n=n,lambda_max=float(lam[0]),residual=float(residual),calls=calls,seconds=time.perf_counter()-t0)
 if lift_path is not None:rec.update(lift_path=str(lift_path),raw_lift_norm=float(norm))
 print(json.dumps(rec),flush=True)
 with open(ROOT/'fft_results.jsonl','a') as f:f.write(json.dumps(rec)+'\n')
 if save:np.savez_compressed(ROOT/f'fft_state_L{L:g}_g{g}_k{k}.npz',p=np.r_[ph,p.ravel()],w=np.r_[wh,wp.ravel()],v=v[:,0],lam=lam,gap=g,h=h,k=k,nh=nh)
 return rec
if __name__=='__main__':
 for L in [20,40,80]:
  for k in [4,8]:solve(L,k=k)
 for L in [120,160,200]:
  for k in [8,12]:solve(L,k=k,save=(L==200))
