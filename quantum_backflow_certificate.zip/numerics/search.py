import os, time, json
os.environ['OPENBLAS_NUM_THREADS']='1'
import numpy as np
from scipy.special import roots_legendre
from scipy.sparse.linalg import eigsh
from scipy.optimize import minimize_scalar
from pathlib import Path
ROOT=Path(__file__).parent
records=[]
def compute(L,n,g,span=None,save=False):
    t0=time.perf_counter(); z,w=roots_legendre(n);p=(z+1)*L/2;w=w*L/2
    scale=1 if span is None else span/(g+2)
    A=np.empty((n,n))
    for i in range(0,n,128):
        pp=p[i:i+128,None];D=pp-p[None,:];S=pp+p[None,:];E=D*S*scale
        A[i:i+128]=(-scale/np.pi*S*np.sinc(E/(2*np.pi))*np.cos((g+1)*E/2))*np.sqrt(w[i:i+128,None]*w[None,:])
    lam,v=eigsh(A,k=1,which='LA',tol=2e-12,v0=np.ones(n),maxiter=1000)
    res=float(np.linalg.norm(A@v[:,0]-lam[0]*v[:,0]))
    rec=dict(L=L,n=n,gap=g,span=span,lambda_max=float(lam[0]),eigen_residual=res,seconds=time.perf_counter()-t0)
    records.append(rec); print(json.dumps(rec),flush=True)
    (ROOT/'search_results.json').write_text(json.dumps(records,indent=2))
    if save: np.savez(ROOT/f'state_L{L}_n{n}_g{g}.npz',p=p,w=w,v=v[:,0],lam=lam,gap=g,scale=scale)
    return rec['lambda_max']
if __name__=='__main__':
    # Stage 1: quadrature reliability and gap sensitivity.
    for L,n in [(20,800),(20,1200),(40,2400),(40,3600)]:
        for g in [1.,1.25,1.5,1.75,2.]: compute(L,n,g)
    # Stage 2: common elapsed time; both intervals shrink equally.
    for g in [1.,1.5,2.]:compute(40,3600,g,span=3)
    # Stage 3: larger supports, check two quadrature resolutions.
    for L,n in [(60,5000),(60,6500),(80,8500),(80,10000)]:
        for g in [1.,1.5]:compute(L,n,g,save=(L==80 and n==10000))
