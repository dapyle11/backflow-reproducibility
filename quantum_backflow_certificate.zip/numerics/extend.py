from fft_solver import solve
for L in [240,320]:
 for g in [1.,1.25,1.4,1.5,1.6,1.75]:solve(L=L,g=g,k=8,save=False)
solve(L=320,g=1.5,k=12,save=True)
