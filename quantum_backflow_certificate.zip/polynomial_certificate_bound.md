# Independent audit: exact-state route and quadrature truncation bound

Audit date: 2026-10-18. This is a mathematical error-bound derivation, not yet a floating-point interval certificate.

## Correct operator
With hbar=1, mass=1/2, the intervals are [-1-g/2,-g/2] and [g/2,1+g/2]. Put E=p^2-q^2. The real symmetric kernel is
K_g(p,q)=-(p+q)/pi * sinc(E/2) * cos((g+1)E/2),
where sinc(x)=sin(x)/x. This equals the program's NumPy-normalized sinc(E/(2*pi)). Diagonal K(p,p)=-2p/pi. Equation 2.24 in the cited HTML reverses interval indices, a typographical error; equations 2.13 and 2.25 give the correct signs.

The benchmark about 0.06185 is b_back^(2)(1,1), for unrestricted momentum but equal interval durations and equal gap. It is not the supremum over interval geometries. Gap g corresponds to the paper's ratio pair (g,1/g).

## Exact normalized trial state
Let p_i,w_i be exact n-point Gauss-Legendre nodes/weights on [0,L]. If real v has sum v_i^2=1, let f be the unique polynomial of degree <=n-1 with f(p_i)=v_i/sqrt(w_i). Extend it by zero outside [0,L]. Then integral f^2=1 exactly, since Gaussian quadrature integrates f^2 exactly. Hence its exact Rayleigh quotient is a valid lower bound on unrestricted backflow at the chosen geometry. There is no unknown tail error for this explicitly compactly supported state.

A convenient reproducible alternative is to record rational or binary-exact coefficients c_k in the orthonormal basis e_k(p)=sqrt((2k+1)/L)P_k(2p/L-1). Normalize by sqrt(sum c_k^2); this separates the precise trial-state definition from approximate quadrature nodes used during optimization.

## Explicit Gaussian quadrature remainder
For ANY real polynomial f of degree <=n-1 with norm 1 on [0,L], use m-point Gauss in each variable to evaluate R=double integral f(p)K_g(p,q)f(q) dp dq. Let rho>1,
a=1/2+(rho+rho^-1)/4,
b=(rho-rho^-1)/4,
T=1+g/2.
Then an exact-arithmetic absolute quadrature remainder bound is

E_bound = [8 L^2 n^2 (a+1)/(pi (1-rho^-1))] * rho^(n-1-2m) * exp(2 T L^2 a b).

For duration scale s (each interval length s, gap sg), multiply prefactor by s and replace T by s(1+g/2).

Proof:
1. On the Bernstein ellipse mapped to [0,L], |p|<=La, |Im p|<=Lb, |Re p|<=La. For q real, |Im(p^2-q^2)|<=2L^2ab.
2. The time-integral expression K=-(p+q)/(2pi) integral_over_two_intervals exp(it(p^2-q^2))dt gives |K|<=L(a+1)/pi * exp(2TL^2ab) when one argument is on the ellipse and the other is real.
3. Legendre's integral representation gives |P_k(z)|<=rho^k on the standard ellipse (write z=(w+w^-1)/2, |w|=rho). Cauchy-Schwarz in the orthonormal expansion gives |f(p)|<=n rho^(n-1)/sqrt(L) on the ellipse and <=n/sqrt(L) on the real interval. Therefore |f(p)K(p,q)f(q)|<=M, where M=n^2(a+1)/pi * rho^(n-1) * exp(2TL^2ab), for either variable on the ellipse and the other real.
4. An analytic function bounded by M on this ellipse has Chebyshev coefficients bounded by 2M rho^-k. Truncate at degree 2m-1: the uniform tail is <=2M rho^-2m/(1-rho^-1). Both integration and positive Gauss quadrature have total weight L; the 1D quadrature error is thus <=4LM rho^-2m/(1-rho^-1).
5. Decompose the tensor error as I_p(I_q-Q_q)+(I_p-Q_p)Q_q. Apply the preceding 1D estimate, integration weight L, and positive quadrature weight L, to obtain 8L^2M rho^-2m/(1-rho^-1).

Conservative examples at rho=1.1, g=1.5:
L=40,n=2400,m=4000 gives log10(E_bound)=-103.788.
L=80,n=10000,m=14000 gives log10(E_bound)=-266.199.
Thus finite quadrature truncation can be bounded far below the needed scientific threshold. This does NOT bound scipy node/weight errors, coefficient construction errors, polynomial-evaluation rounding, kernel rounding, or accumulation rounding. A real numerical certificate still needs interval arithmetic or separately justified explicit floating-point error bounds. Repeated quadrature agreement is evidence, not a certificate.

## Comparison and scope
Changing g at fixed duration changes total elapsed span. At fixed span S, use s=S/(g+2). Unrestricted operators are unitarily equivalent to the duration-one versions, but the same numerical momentum cutoff L then corresponds to duration-one cutoff sqrt(s)*L. Finite-cutoff comparisons therefore must specify which resource is held fixed.

A lower bound at g!=1 cannot by itself prove superiority to the true unrestricted g=1 optimum without a rigorous upper bound for g=1. The published accelerated numerical upper estimate is explicitly conjectural. A validated trial state exceeding 0.06186 would be compelling numerical evidence, not a theorem of superiority to equal spacing.

Primary source: https://arxiv.org/html/2505.13184v1 (equations 2.13,2.25,A.11; Table 5.5).
Public code/data: https://github.com/hkk506/Repeated-quantum-backflow-and-quantum-overflow/ (README scopes code to section 5 equal spacing).
