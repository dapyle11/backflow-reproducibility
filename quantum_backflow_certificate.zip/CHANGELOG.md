# Version 2 changes
18 October 2026

- Added explicit disclosure that calculations, code, write-up and audits were AI-generated or AI-assisted, with computational reruns and no outside human specialist review.
- Clarified the comparison geometry, local-search cutoff, probability interpretation and reproduction entrypoints; corrected Kirk-Karakaya’s surname.
- Removed the percentage shorthand and unmeasured memory-use claim.
- Added a mandatory expected-state SHA256 check before numerical computation and tests rejecting intentional changes to the archive, including under Python optimization.
- Annotated the preserved numerical history to correct the arXiv v1 table label and overgeneralized residual claim.
- Refreshed the executable verification, document render and package checksums.

The numerical enclosure and conservative lower bound R > 0.06190 are unchanged. This remains conditional on the documented arithmetic/library assumptions; optimality and publication priority are not established.
