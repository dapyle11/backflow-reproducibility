#include <math.h>
#include <float.h>
#include <stdlib.h>
#include <stdint.h>
#include <fenv.h>
#include <xmmintrin.h>
// MPFR ABI declarations; binary library libmpfr.so.6 implements these public APIs.
typedef struct {long prec; int sign; long exp; unsigned long *limbs;} mpfr_struct;
typedef mpfr_struct mpfr_t[1];
extern void mpfr_init2(mpfr_t,long);
extern void mpfr_clear(mpfr_t);
extern int mpfr_set_si(mpfr_t,long,int);
extern int mpfr_div_ui(mpfr_t,const mpfr_t,unsigned long,int);
extern int mpfr_mul_ui(mpfr_t,const mpfr_t,unsigned long,int);
extern int mpfr_const_pi(mpfr_t,int);
extern int mpfr_sin(mpfr_t,const mpfr_t,int);
extern int mpfr_cos(mpfr_t,const mpfr_t,int);
extern double mpfr_get_d(const mpfr_t,int);
// Rounding occurs at 128 bits then at binary64: absolute error <2^-52.
void trig_table(int n,double *s,double *c,double *s25,double *c25){
 mpfr_t x,y,t;mpfr_init2(x,128);mpfr_init2(y,128);mpfr_init2(t,128);
 for(int j=0;j<n;j++){
 mpfr_set_si(x,j,0);mpfr_sin(y,x,0);s[j]=mpfr_get_d(y,0);mpfr_cos(y,x,0);c[j]=mpfr_get_d(y,0);
 mpfr_mul_ui(t,x,5,0);mpfr_div_ui(t,t,2,0);mpfr_sin(y,t,0);s25[j]=mpfr_get_d(y,0);mpfr_cos(y,t,0);c25[j]=mpfr_get_d(y,0);
 }mpfr_clear(x);mpfr_clear(y);mpfr_clear(t);
}
void twiddles(int n,double *re,double *im){
 mpfr_t x,y,t;mpfr_init2(x,128);mpfr_init2(y,128);mpfr_init2(t,128);mpfr_const_pi(t,0);
 for(int j=0;j<n/2;j++){mpfr_mul_ui(x,t,2*j,0);mpfr_div_ui(x,x,n,0);mpfr_cos(y,x,0);re[j]=mpfr_get_d(y,0);mpfr_sin(y,x,0);im[j]=-mpfr_get_d(y,0);}
 mpfr_clear(x);mpfr_clear(y);mpfr_clear(t);
}
void fft(int n,double *re,double *im,const double *wr,const double *wi){
 for(int i=1,j=0;i<n;i++){int bit=n>>1;for(;j&bit;bit>>=1)j^=bit;j^=bit;if(i<j){double t=re[i];re[i]=re[j];re[j]=t;t=im[i];im[i]=im[j];im[j]=t;}}
 for(int len=2;len<=n;len<<=1){int h=len/2,step=n/len;for(int base=0;base<n;base+=len){for(int j=0;j<h;j++){int a=base+j,b=a+h,k=j*step;double r=wr[k]*re[b]-wi[k]*im[b],s=wr[k]*im[b]+wi[k]*re[b];double ar=re[a],ai=im[a];re[a]=ar+r;im[a]=ai+s;re[b]=ar-r;im[b]=ai-s;}}}
}
double triple(int n,const double *ar,const double *ai,const double *kr,const double *ki,const double *br,const double *bi){
 long double out=0;
 for(int j=0;j<n;j++){long double r=(long double)kr[j]*br[j]-(long double)ki[j]*bi[j],s=(long double)kr[j]*bi[j]+(long double)ki[j]*br[j];out+=(long double)ar[j]*r+(long double)ai[j]*s;}
 return (double)(out/n);
}
int longdouble_bits(){return LDBL_MANT_DIG;}

int arithmetic_environment_ok(){return FLT_RADIX==2 && DBL_MANT_DIG==53 && sizeof(double)==8 && LDBL_MANT_DIG>=64 && fegetround()==FE_TONEAREST && ((_mm_getcsr() & ((1<<15)|(1<<6)))==0);}
