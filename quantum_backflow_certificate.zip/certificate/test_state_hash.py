"""Positive preflight and negative full-process tests for both entrypoints."""
from pathlib import Path
import subprocess, sys, tempfile, json
HERE=Path(__file__).resolve().parent
sources={name:(HERE/name).read_text() for name in ('verify.py','independent_verify.py')}
# Both verification paths must share every mathematical and safety guard.
assert sources['independent_verify.py']==sources['verify.py'].replace("ROOT/'verified_fft.so'","ROOT/'audit_fft.so'").replace("ROOT/'result.json'","ROOT/'independent_result.json'")
results={'entrypoint_guard_and_math_parity':'passed'}
for name,source in sources.items():
 # Production preflight stops before initializing/loading the FFT helper.
 prefix=source.split('mp.iv.dps=100',1)[0]
 namespace={'__file__':str(HERE/name)}
 exec(compile(prefix,str(HERE/name),'exec'),namespace)
 assert namespace['STATE_SHA256']==namespace['EXPECTED_STATE_SHA256']
 assert 'lib' not in namespace
 results[name]={'expected_state_preflight':'passed','fft_helper_loaded_in_preflight':False}
 with tempfile.TemporaryDirectory(prefix='backflow-hash-negative-') as directory:
  root=Path(directory);child=root/'certificate';child.mkdir()
  (child/name).write_text(source)
  data=bytearray(namespace['STATE_BYTES']);data[-1]^=1
  (root/'explicit_state_L320_g1.5.npz').write_bytes(data)
  # No helper library exists here: mismatches must fail before its load.
  for flags in ([],['-O']):
   run=subprocess.run([sys.executable,*flags,str(child/name)],text=True,capture_output=True)
   assert run.returncode!=0
   assert 'ValueError: State SHA256 mismatch:' in run.stderr,run.stderr
   assert 'OSError' not in run.stderr
   assert not list(child.glob('*result.json'))
   results[name]['modified_state_rejection'+('_optimized' if flags else '')]='passed before FFT helper load/computation'
(HERE/'hash_test_results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
