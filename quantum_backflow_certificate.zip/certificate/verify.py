"""Independent interval-input / explicitly bounded radix-2 FFT certificate.
Run python verify.py. Only exact binary64 coefficients are read from NPZ.
No eigensolver, scipy FFT, or ordinary libm trigonometric value enters the proof.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import numpy as np, mpmath as mp, ctypes as ct, json, time, hashlib, io
from scipy.special import roots_legendre
ROOT=Path(__file__).resolve().parent; DATA=ROOT.parent/'explicit_state_L320_g1.5.npz'
EXPECTED_STATE_SHA256='23c0a9394e820932e48be943ad90d3a87bab6faba6b651e004b99aa8c4460aa9'
# Fail closed before loading the FFT helper or starting numerical verification.
# Parse the very same bytes that were hashed, avoiding a second file read.
STATE_BYTES=DATA.read_bytes()
STATE_SHA256=hashlib.sha256(STATE_BYTES).hexdigest()
if STATE_SHA256 != EXPECTED_STATE_SHA256:
 raise ValueError(f'State SHA256 mismatch: expected {EXPECTED_STATE_SHA256}, got {STATE_SHA256}')
mp.iv.dps=100
u=2.**-53
P=ct.POINTER(ct.c_double);lib=ct.CDLL(str(ROOT/'verified_fft.so'))
lib.fft.argtypes=[ct.c_int,P,P,P,P];lib.triple.argtypes=[ct.c_int]+[P]*6;lib.triple.restype=ct.c_double
lib.twiddles.argtypes=[ct.c_int,P,P];lib.trig_table.argtypes=[ct.c_int,P,P,P,P]
assert lib.longdouble_bits()>=64
assert lib.arithmetic_environment_ok(), 'Need IEEE binary64 nearest rounding and gradual underflow'

def ptr(a):return a.ctypes.data_as(P)
def down(x):return np.nextafter(x,-np.inf)
def up(x):return np.nextafter(x,np.inf)
def iv(x):return (np.asarray(x,dtype=float),np.asarray(x,dtype=float))
def add(a,b):return down(a[0]+b[0]),up(a[1]+b[1])
def neg(a):return -a[1],-a[0]
def sub(a,b):return add(a,neg(b))
def mul(a,b):
 v=np.array([a[0]*b[0],a[0]*b[1],a[1]*b[0],a[1]*b[1]])
 return down(v.min(axis=0)),up(v.max(axis=0))
def div(a,b):
 assert np.all((b[0]>0)|(b[1]<0))
 return mul(a,(down(1/b[1]),up(1/b[0])))
def sqrt(a):assert np.all(a[0]>=0);return down(np.sqrt(a[0])),up(np.sqrt(a[1]))
def frommp(x):return (np.asarray(down(float(x.a))),np.asarray(up(float(x.b))))
def midrad(a):
 c=(a[0]+a[1])/2
 r=up(np.maximum(c-a[0],a[1]-c));return c,r
# Positive sums contain <= 2^22 terms, so factor 1.000001 safely exceeds gamma_n.
def sumup(x):return float(np.sum(x,dtype=np.float64))*1.000001+1e-300
def normup(x):return float(np.sqrt(sumup(up(x*x))))*1.000001

def legendre(n,x):
 p0=mp.iv.mpf(1)
 if n==0:return p0
 p1=x
 for j in range(1,n):p0,p1=p1,((2*j+1)*x*p1-j*p0)/(j+1)
 return p1

def gauss(n):
 # Approximate roots merely locate disjoint rational brackets. Opposite signs,
 # n disjoint brackets and polynomial degree n certify ALL roots exactly.
 approximate=roots_legendre(n)[0];zs=[];ws=[];last=None
 for z in approximate:
  a=mp.mpf(float(z))._mpf_;center=mp.iv.mpf(float(z));eps=mp.iv.mpf(2)**-48
  lo=center-eps;hi=center+eps
  assert legendre(n,lo).b*legendre(n,hi).a<0 or legendre(n,lo).a*legendre(n,hi).b<0
  # Refine by signs using exact dyadic endpoints represented as Python integers.
  den=2**180;cnum=int(float(z)*2**52)*2**128;step=2**132
  l=cnum-step;r=cnum+step
  def sgn(num):
   val=legendre(n,mp.iv.mpf(num)/den)
   if val.a>0:return 1
   if val.b<0:return -1
   raise ArithmeticError('root sign inconclusive')
  sl=sgn(l);sr=sgn(r);assert sl*sr==-1
  while r-l>2:
   mid=(l+r)//2;sm=sgn(mid)
   if sm==sl:l=mid
   else:r=mid
  assert last is None or l>last;last=r
  x=mp.iv.mpf([mp.iv.mpf(l)/den,mp.iv.mpf(r)/den]);zs.append(x)
  dp=n*(x*legendre(n,x)-legendre(n-1,x))/(x*x-1)
  ws.append(2/((1-x*x)*dp*dp))
 return zs,ws

def basis_values(zs,degree,length):
 out=[]
 for z in zs:out.append([frommp(mp.iv.sqrt((2*l+1)/length)*legendre(l,z)) for l in range(degree)])
 return out

def polys(coeff,basis):
 out=[]
 for row in basis:
  y=iv(np.zeros(coeff.shape[1:] or ()))
  for j,b in enumerate(row):y=add(y,mul(iv(coeff[j]),b))
  out.append(y)
 return out

def fft(a):
 re=np.zeros(N);re[:len(a)]=a;im=np.zeros(N);lib.fft(N,ptr(re),ptr(im),ptr(wr),ptr(wi));return re,im

def triple(a,k,b):return lib.triple(N,*map(ptr,(*a,*k,*b)))

def sincos_offset(s,c,off):
 si=frommp(mp.iv.sin(off));co=frommp(mp.iv.cos(off))
 return add(mul(s,co),mul(c,si)),sub(mul(c,co),mul(s,si))

start=time.time();data=np.load(io.BytesIO(STATE_BYTES));hc=data['head_coeff'];tc=data['tail_coeff'];m=tc.shape[1];N=1<<((2*m-1).bit_length())
assert m==51199 and tc.shape[0]==12 and len(hc)==32
wr=np.empty(N//2);wi=np.empty(N//2);lib.twiddles(N,ptr(wr),ptr(wi))
tables=[np.empty(m+1) for _ in range(4)];lib.trig_table(m+1,*map(ptr,tables))
# Each table input is an exact integer/half-integer. At precision128,
# MPFR error plus binary64 conversion error is below 2^-52 absolutely.
tableiv=[(down(a-2**-52),up(a+2**-52)) for a in tables]
pi=frommp(mp.iv.pi);rt2=frommp(mp.iv.sqrt(2));zh,wh=gauss(64);zt,wt=gauss(48)
off=[z+1 for z in zt];pv=[(z+1)/mp.iv.sqrt(2) for z in zh]
hvals=polys(hc,basis_values(zh,32,mp.iv.sqrt(2)))
H=[mul(v,frommp(w/mp.iv.sqrt(2))) for v,w in zip(hvals,wh)]
tvals=polys(tc,basis_values(zt,12,mp.iv.mpf(2)))
AA=[];BB=[];dA=[];dB=[];nA=[];nB=[]
jj=np.arange(1,m+1,dtype=float)
for r in range(48):
 x=add(iv(2*jj),frommp(off[r]));q=sqrt(sqrt(x));f=mul(tvals[r],frommp(wt[r]))
 a,ra=midrad(mul(f,q));b,rb=midrad(div(f,q))
 AA.append(fft(a));BB.append(fft(b));dA.append(normup(ra));dB.append(normup(rb));nA.append(normup(a));nB.append(normup(b))
 if r==0:Am=[];Bm=[];Ar=[];Br=[]
 Am.append(a);Bm.append(b);Ar.append(ra);Br.append(rb)
print('inputs ready',time.time()-start,'norm bounds',sum(nA),sum(nB),'errors',sum(dA),sum(dB),flush=True)
# C radix2 FFT error in 2-norm <=eta||x||: each butterfly has relative
# error <=32u with correctly rounded twiddles (absolute complex error<4u).
# eta=(1+32u)^17-1 <1e-12. Long-double spectral summation contributes
# <2e-13 ||A||||B||||K||_1. 4e-12 bounds three transforms plus summation.
ETA=4e-12
# Signed integer differences -(m-1)..m-1.
dd=np.arange(-(m-1),m,dtype=float);ind=np.abs(dd).astype(int);sgn=np.sign(dd)
sbase=mul((tableiv[0][0][ind],tableiv[0][1][ind]),iv(sgn));cbase=(tableiv[1][0][ind],tableiv[1][1][ind])
s25base=mul((tableiv[2][0][ind],tableiv[2][1][ind]),iv(sgn));c25base=(tableiv[3][0][ind],tableiv[3][1][ind])
Qtail=0.;Etail=0.;maxkl1=0.
for r in range(48):
 for s in range(r,48):
  delta=off[r]-off[s]
  sn,_=sincos_offset(sbase,cbase,delta/2);_,cs=sincos_offset(s25base,c25base,delta*mp.iv.mpf('1.25'))
  e=add(iv(2*dd),frommp(delta));safe=(e[0].copy(),e[1].copy())
  if r==s:safe[0][m-1]=safe[1][m-1]=1
  kval=neg(div(mul(sn,cs),mul(pi,safe)))
  if r==s:
   diag=neg(div(iv(1.),mul(iv(2.),pi)));kval[0][m-1]=diag[0];kval[1][m-1]=diag[1]
  kc,kr=midrad(kval);kn=sumup(np.abs(kc));dk=sumup(kr);maxkl1=max(maxkl1,kn)
  emb=np.zeros(N);emb[:m]=kc[m-1:];emb[-m+1:]=kc[:m-1]
  F=fft(emb)
  val=triple(AA[r],F,BB[s]);err=ETA*nA[r]*nB[s]*kn + dk*nA[r]*nB[s]+(kn+dk)*(dA[r]*nB[s]+nA[r]*dB[s]+dA[r]*dB[s])
  if r!=s:
   Fc=(F[0],-F[1]);val+=triple(AA[s],Fc,BB[r]);err+=ETA*nA[s]*nB[r]*kn+dk*nA[s]*nB[r]+(kn+dk)*(dA[s]*nB[r]+nA[s]*dB[r]+dA[s]*dB[r])
  Qtail+=2*val;Etail+=2*err
 if r%4==0:print('tail',r,Qtail,Etail,'sec',time.time()-start,flush=True)
# Head/head evaluated wholly with scalar interval arithmetic.
Qhh=iv(0.)
for r in range(64):
 for s in range(64):
  e=pv[r]*pv[r]-pv[s]*pv[s]
  if r==s:k=frommp(-2*pv[r]/mp.iv.pi)
  else:k=frommp(-(pv[r]+pv[s])*2/mp.iv.pi*mp.iv.sin(e/2)*mp.iv.cos(mp.iv.mpf('1.25')*e)/e)
  Qhh=add(Qhh,mul(mul(H[r],H[s]),k))
# Mixed block: K transformed times wx*phi = sqrt2*c(E)*(A+p_head*B).
sj=(tableiv[0][0][1:],tableiv[0][1][1:]);cj=(tableiv[1][0][1:],tableiv[1][1][1:]);s25j=(tableiv[2][0][1:],tableiv[2][1][1:]);c25j=(tableiv[3][0][1:],tableiv[3][1][1:])
Qmixed=iv(0.)
for r in range(64):
 for s in range(48):
  delta=off[s]-pv[r]*pv[r]
  sn,_=sincos_offset(sj,cj,delta/2);_,cs=sincos_offset(s25j,c25j,delta*mp.iv.mpf('1.25'))
  e=add(iv(2*jj),frommp(delta));kv=neg(div(mul(sn,cs),mul(pi,e)))
  av=(down(Am[s]-Ar[s]),up(Am[s]+Ar[s]));bv=(down(Bm[s]-Br[s]),up(Bm[s]+Br[s]))
  terms=mul(kv,add(av,mul(frommp(pv[r]),bv)))
  # Sum midpoint/radius with conservative naive-summation gamma_m bound.
  mid,rad=midrad(terms);sm=float(np.sum(mid));er=sumup(rad)+sumup(np.abs(mid))*2e-11
  block=(down(sm-er),up(sm+er));Qmixed=add(Qmixed,mul(mul(mul(iv(2.),rt2),H[r]),block))
 if r%8==0:print('mixed',r,Qmixed,'sec',time.time()-start,flush=True)
# Coefficient squared norm obtained exactly with rational Python arithmetic.
from fractions import Fraction
S=sum((Fraction(float(c))**2 for c in np.r_[hc,tc.ravel()]),Fraction(0))
Si=frommp(mp.iv.mpf(S.numerator)/S.denominator)
# Additional 1e-8 encompasses final accumulation and comfortably dominates its
# explicit 2352-term binary64 gamma bound, provided absolute sum below 1e4.
# We enforce a stronger bound from Young's inequality.
absbound=2*maxkl1*sum(nA)*sum(nB)
assert absbound<1e4
Eacc=1e-8
num=add(add((down(down(Qtail-Etail)-Eacc),up(up(Qtail+Etail)+Eacc)),Qhh),Qmixed)
C=2*mp.iv.sqrt(320**2+mp.iv.mpf(1)/4)/mp.iv.pi*mp.iv.exp(mp.iv.mpf(7)/4*mp.iv.mpf(27)/16)
B2=1024*mp.iv.sqrt(2)+51199*288
A2=1024*mp.iv.sqrt(2)*mp.iv.mpf(2)**-194+51199*288*mp.iv.mpf(2)**-170
quad=16*C*mp.iv.sqrt(A2*B2)
assert quad.b<mp.iv.mpf('2.382e-14')
result=div(num,Si);result=(down(result[0]-2.382e-14),up(result[1]+2.382e-14))
report=dict(sha256=STATE_SHA256,tail=Qtail,tail_error=Etail,head=[float(x) for x in Qhh],mixed=[float(x) for x in Qmixed],norm=[float(x) for x in Si],quotient_interval=[float(x) for x in result],absbound=absbound,max_kernel_l1=maxkl1,seconds=time.time()-start,fft_N=N)
(ROOT/'result.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
assert result[0]>0.06190
