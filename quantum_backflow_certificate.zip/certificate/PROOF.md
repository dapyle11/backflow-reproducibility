# Executable lower-bound certificate: proof and assumptions

## Claim and scope
The exact binary64 coefficient archive `../explicit_state_L320_g1.5.npz` defines a compactly supported positive-momentum trial state. The normalized double-integral backflow Rayleigh quotient at gap 3/2 is enclosed by the verifier. This is a lower bound at this geometry, not an upper bound or an optimization proof. It does not prove superiority to the true equal-spacing supremum.

The archive SHA256 is `23c0a9394e820932e48be943ad90d3a87bab6faba6b651e004b99aa8c4460aa9`. Both verifier entrypoints explicitly reject a mismatch before loading their FFT helper or starting numerical verification. The same in-memory bytes that passed this check are then parsed; no second file read is used for the state.

Head basis: sqrt((2l+1)/sqrt(2)) P_l(sqrt(2)p-1), 0<=p<=sqrt(2), l=0,...,31. Tail panel j=1,...,51199: in x=p² on [2j,2j+2], phi_j(x)=sum_l c_lj sqrt((2l+1)/2) P_l(x-2j-1), l=0,...,11; physical psi(p)=sqrt(2p)phi_j(p²). Zero outside [0,320]. Divide by sqrt(S), where S is the exact sum of squares of every binary-rational coefficient. `verify.py` recomputes S using Python Fraction; no approximate norm stored in the archive is trusted.

## Arithmetic trust base
Assume IEEE-754 binary64 round-to-nearest elementary arithmetic and correctly rounded square root, with no fast-math reassociation or overflow. FFT underflow terms, if any, contribute less than 1e-280 after all finitely many operations and amplifications, negligible within the explicit final 1e-8 padding. Interval operations expand both endpoints by nextafter after each elementary operation. Tiny subnormal zeros are harmless; positive error sums include an additive 1e-300 cushion. `numpy.sum` may use any summation ordering: a deliberately loose sequential gamma_n bound covers it. Arrays summed have at most 2^22 entries, so multiplying positive sums by 1.000001 is safely outward.

The C arithmetic-environment check asserts radix 2, a 53-bit double significand, round-to-nearest, and SSE flush-to-zero/denormals-are-zero disabled. The C file is compiled with `-fno-fast-math -ffp-contract=off`. Its long-double significand must have at least 64 bits (checked at runtime). MPFR public library API is used at 128 bits. Correct-rounding semantics are specified at https://mpfr.org/mpfr-current/mpfr.html. The few small-node interval calculations use mpmath.iv, an interval-arithmetic library. The proof is a reproducible numerical certificate conditional on these arithmetic/library semantics, not a formal proof-assistant verification of the machine or libraries.

## Gauss quadrature and interval input evaluation
SciPy supplies initial approximate roots only. Each approximate root is enclosed in an exact dyadic rational bracket and both endpoint signs of P_n are certified using interval Legendre recurrence. The n brackets are disjoint, sign-changing, and refined to width <=2^-179. A degree-n polynomial cannot have more than n roots, so these brackets certify all Gauss roots. The weight formula 2/[(1-z²)P'_n(z)²] is interval evaluated. Head order64 and tail order48 are used.

Legendre basis values, quadrature weights, head samples, and tail vectors are interval evaluated. On the tail set
A_rj=w_r phi_j(x_rj) x_rj^(1/4),
B_rj=w_r phi_j(x_rj) x_rj^(-1/4).
Their stored midpoints and Euclidean radius norms give explicit input errors. Square/fourth roots use outward interval square roots, not a fractional-power libm approximation.

## Trigonometric kernel enclosures
Write c(E)=-sin(E/2)cos(5E/4)/(pi E), with c(0)=-1/(2pi). Tail/tail E=2d+delta, where d is integer and delta is the difference of certified Gauss offsets. MPFR computes sin(d),cos(d),sin(5d/2),cos(5d/2) at 128 bits and rounds to binary64. All input d and 5d/2 are exact. An absolute radius 2^-52 safely covers the high-precision rounding followed by binary64 rounding. Signed d uses exact odd/even symmetries. Certified mpmath.iv sine/cosine of the small offset and interval trig-addition formulas give kernel entries. Thus no uncontrolled large-argument libm evaluation occurs.

Mixed E=2j+offset-p_head² uses the same tables. The head/head kernel is interval evaluated directly. Diagonal c(0) is handled analytically. Every denominator interval must exclude zero.

## Explicit FFT error lemma
Let u=2^-53, N=131072, s=log2 N=17. Twiddle factors come from MPFR pi and sine/cosine at 128 bits, subsequently rounded to binary64. Their complex absolute error is below4u.

Each C radix-2 butterfly uses explicit real operations. A complex multiplication by an approximate unit twiddle has error at most16u times the modulus of its input; the two final complex additions contribute at most u times the magnitudes of their operands per component. The resulting butterfly's error in Euclidean norm is below32u times the norm of the exact butterfly output. The same triangle inequalities give a componentwise absolute error bounded by32u times the local sum of input moduli. Induction through s stages therefore gives both:

- ||FFT_fl(v)-FFT(v)||_2 <= eta sqrt(N)||v||_2;
- max_j |FFT_fl(v)_j-FFT(v)_j| <= eta ||v||_1;

where eta=(1+32u)^17-1 < 1e-12. Bit reversal is an exact permutation. The deliberately loose eta allows substantial slack over the elementary bound (~6.1e-14).

## Convolution quadratic form and its error
Zero-padded Toeplitz kernels are embedded at length N, with positive differences at the beginning and negative differences at the end. For real vectors A,B and kernel k,
A^T T_k B = (1/N) Re sum_j conj(FA_j) Fk_j FB_j.
The C `triple` implementation computes precisely this real expression. Swapping offset indices transposes the Toeplitz matrix, equivalent to conjugating Fk. The total tail numerator is 2 sum_rs A_r^T T_rs B_s.

Use the FFT l2 bound for A and B, and the componentwise l1 bound for k. By Cauchy-Schwarz, the three FFT errors contribute at most [(1+eta)^3-1] ||A||_2 ||B||_2 ||k||_1. Long-double evaluation/accumulation has unit roundoff <=2^-64. Its expanded absolute sum is bounded by 2sqrt(2) times sum |FA||Fk||FB|. A sequential gamma_(N+6) bound, power-of-two division, and final binary64 conversion contribute less than 2e-13 times ||A||||B||||k||_1. The implemented combined allowance is therefore 4e-12 ||A||||B||||k||_1.

Let alpha,beta bound the input midpoint-vector errors and epsilon bound the kernel midpoint l1 error. The additional perturbation allowance is

epsilon ||A||||B|| + (||k||_1+epsilon)(alpha||B||+||A||beta+alpha beta).

All vector norms and positive error sums receive outward cushions. The recorded largest kernel l1 bound and sum of vector norms establish a global absolute sum bound below 1e4 (in fact about3.3). A final 1e-8 allowance covers all scalar tail/error-budget accumulation. Explicitly, with u=2^-53, gamma_2352=2352u/(1-2352u)<2.612e-13. The enforced absolute-sum bound below1e4 therefore gives a sequential tail-accumulation error below2.612e-9, already below the reserve. The recorded tighter bound3.290692616611022 gives error below8.60e-13. Rounding in the much smaller positive error-budget accumulation and final endpoint preparation is also safely absorbed by the remaining reserve. The bound uses an arbitrary sequential summation ordering, not an empirical estimate from repeated runs.

## Head and mixed terms
Head/head uses full interval arithmetic. For a tail vector the transformed head/tail term is sqrt(2)c(E)(A+p_head B). The full mixed numerator is twice this, multiplied by w_head psi_head. The code interval evaluates every summand. The vector sum uses midpoint/radius form plus a conservative 2e-11 times the absolute midpoint sum, exceeding the binary64 sequential gamma_51199 bound.

## Quadrature remainder
Use the derivation in `../mixed_panel_certificate_bound.md`. With rho=2,
C=2sqrt(320²+1/4)/pi * exp((7/4)(27/16)),
B²=1024sqrt(2)+51199*288,
A²=1024sqrt(2)*2^-194+51199*288*2^-170.
The normalized double-integral quadrature error is at most16C sqrt(A²B²)<2.382e-14. This bounds quadrature for the exact normalized state; there is no unbounded momentum tail because the state is explicitly zero beyond320.

Finally interval-divide the entire numerator by the exact S enclosure and expand by the analytic quadrature remainder. If the lower endpoint exceeds0.06190, the target lower bound is certified under the stated arithmetic assumptions.
