# Compact-support backflow certificate

Run `./run.sh` from this directory. Requirements: Linux/x86-64, gcc, libmpfr.so.6, Python, NumPy, SciPy, and mpmath. No network access is needed. Runtime is about two minutes; memory use was not measured.

Input: `../explicit_state_L320_g1.5.npz`. Its binary64 coefficients define exact binary rationals; the generator/eigensolver is not part of the certificate. Read `PROOF.md` for the exact state, normalization, interval arithmetic, FFT error lemma, and analytic quadrature remainder.

Expected result: an enclosure approximately `[0.0619551065, 0.0619551266]` for the normalized trial-state Rayleigh quotient. The script asserts the lower endpoint is above `0.06190`. `result.json` records the interval, individual blocks, coefficient-archive hash, and timing. `run_review.log` records the reviewed primary verification run.

This proves only a lower bound at the chosen unequal-gap geometry, conditional on the documented numerical arithmetic/library semantics. It does not certify an optimum or establish that this geometry beats the true equal-spacing optimum.

`run_independent.sh` separately compiles the same C source and runs `independent_verify.py`. That entrypoint differs from the primary verifier only in helper/result filenames; `test_state_hash.py` checks this exact parity. This is a separate rebuild/rerun, not an independently designed second numerical algorithm. Its output is `independent_result.json` and its recorded run is `independent_review.log`.

Review v2: the verifier rejects a state-archive SHA256 mismatch before loading its native helper or running quadrature/FFT computation. It parses the same in-memory bytes whose hash was checked. The final existing assertion requires the lower endpoint to exceed 0.06190. Run normally (not with Python optimization flags), because other mathematical guards use Python assertions.
