#!/bin/sh
set -eu
cd "$(dirname "$0")"
gcc -O2 -shared -fPIC -fno-fast-math -ffp-contract=off verified_fft.c -o verified_fft.so -Wl,-l:libmpfr.so.6 -lm
python verify.py
