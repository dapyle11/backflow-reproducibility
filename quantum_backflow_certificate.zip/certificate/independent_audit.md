# Independent verifier audit

Auditor examined verify.py and verified_fft.c on 2026-10-18, and separately compiled the C source with:

gcc -O2 -std=c11 -fPIC -shared -fno-fast-math -ffp-contract=off verified_fft.c -Wl,-l:libmpfr.so.6 -o audit_fft.so

The script independent_verify.py loads that independently compiled binary, writes independent_result.json, and otherwise preserves the verifier logic. This is an independent audit/rebuild/rerun, not an independently designed second interval algorithm.

## Checked mathematical structure
- Exact binary64 Legendre coefficients define the state independently of any approximate optimizer or original Nyström nodes.
- Coefficient squared norm uses exact Fraction arithmetic. Orthonormal Legendre coordinates correctly use physical momentum on [0,sqrt(2)] and energy x=p^2 on every tail panel [2j,2j+2].
- Gaussian roots are certified by disjoint dyadic brackets with opposite rigorously evaluated polynomial signs; degree n and n distinct brackets account for all roots. Interval derivative formula gives weight enclosures.
- AA contains wx*phi*x^(1/4), BB contains wx*phi*x^(-1/4). The tail kernel coefficient is -sin(E/2)cos(1.25E)/(pi E). Both symmetric terms are accounted for by doubling sum A^T K B.
- Toeplitz circulant embedding uses k[i-j]. Fourier triple computes Re(conj(FA)*FK*FB)/N. A separate random small direct double-sum check confirms orientation. Reversing r,s requires conjugating FK and is correct.
- Head/head and head/tail factors, including 2sqrt(2) for the mixed quadratic block, check against the original momentum kernel.
- Analytic quadrature remainder 2.382e-14 applies after normalization; see mixed_panel_certificate_bound.md.

## FFT error justification
The necessary assumptions are IEEE binary64 round-to-nearest basic operations, ordinary gradual underflow (or explicit negligible underflow allowance), and no compiler reassociation/fast-math. Long-double mantissa has >=64 bits, checked at runtime. The audit rebuild disables fast math and contraction.

Let u=2^-53. MPFR128 twiddles differ from exact unit-modulus twiddles by <4u in complex modulus (in fact much less). A complex multiplication formed from four real multiplications and two additions has absolute error bounded by a small constant times u|z|; including twiddle perturbation, 16u|z| is conservative. Two subsequent complex additions in a butterfly contribute at most u times their componentwise magnitudes. Comparing with the exact butterfly, whose singular values are sqrt(2), gives normalized-stage L2 perturbation <32u. Inducting through 17 stages yields relative L2 forward error <=(1+32u)^17-1<1e-12 for state vectors.

A second, distinct bound is needed for the kernel transform: the same butterfly tree bounds each output error by [(1+32u)^17-1] times the sum of absolute input entries. Thus ||delta FK||infinity<=1e-12||k||1. An L2 bound alone would NOT establish the stated convolution budget.

Parseval and Cauchy-Schwarz then give error from all three transforms <=[(1+1e-12)^3-1]||A||2||B||2||k||1. The long-double spectral summation uses 131072 terms; with u_ld<=2^-64, its naive gamma bound plus per-term operations is well below 2e-13 of the same norm product. Conversion of its result back to double is also covered. Combined 4e-12 is conservative.

Input-radius corrections use Young's convolution bound ||T_k||2<=||k||1. The code includes deltaA, deltaB, deltaK and their needed cross terms. Norms and positive sums use deliberately inflated upper bounds.

Final binary64 tail accumulation has 2352 contributions, and their total absolute magnitude is bounded by approximately3.3 from Young's inequality. Its worst-case error is <1e-11, far below the reserved1e-8. This reserve also covers rounding while accumulating the small positive tail-error budgets. Underflow absolute contributions, if any, are astronomically below this reserve; no overflow occurs for the bounded arrays.

## Other arithmetic checks
Each basic interval endpoint operation is widened by nextafter. mpmath interval endpoints are converted to binary64 and widened again. np.sqrt is assumed correctly rounded on this IEEE platform. Positive-sum inflation1.000001 dominates gamma_n for n<=2^22. Mixed-block signed summation reserves2e-11 times the absolute sum for51199 terms, exceeding the naive binary64 gamma bound (~5.69e-12).

The numerical conclusion remains conditional on ordinary trusted-library/platform semantics (mpmath interval arithmetic, correctly rounded MPFR, IEEE basic operations), as is usual for a computational interval proof. It is not a formally verified theorem-prover certificate. The conservative claim should be a simple lower bound0.06190, not every displayed decimal digit and not superiority to an unproven equal-spacing upper bound.

## Completed independent run
The separately compiled audit_fft.so run completed successfully in109.57seconds and reproduced the quotient enclosure [0.06195510650587079,0.06195512654165395]. It supports the deliberately conservative conclusion R>0.06190. The artifact hash is23c0a9394e820932e48be943ad90d3a87bab6faba6b651e004b99aa8c4460aa9. A separately rebuilt arithmetic-environment check returned true and long-double mantissa64. See history/certificate_v1_independent_result.json and history/certificate_v1_independent_recompiled_run.log, relative to the package root. The current v2 rerun is in certificate/independent_result.json and certificate/independent_review.log.
