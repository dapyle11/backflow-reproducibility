> Version 2 editorial annotation (18 October 2026): This historical numerical-only report is preserved below as originally written. Its Table 5.5 reference is to arXiv v1, not the final published Table 2. Its blanket residual claim in the convergence section is too strong: the recorded discrete eigensolve residuals range approximately from 1e-16 to 4.3e-13. Fixed-state reintegration residuals near 9.6e-12 are not eigensolver convergence claims. The final certificate supersedes this report’s uncertified status.

# A first computational attempt: two-interval quantum backflow

Date: 18 October 2026. Status: reproducible numerical candidate, **not a certified new bound, proved optimum, or verified novel result**.

## Main finding
An explicit finite-momentum-supported state for two unit-duration intervals with gap 1.5 has a numerically evaluated total backflow of approximately **0.06195511652376**. This exceeds the published equal-spacing numerical estimate (conjectured interval 0.0618453024–0.0618597497), without extrapolating our momentum cutoff. The published comparison interval is itself conjectural, so this does not constitute a proof that equal spacing is suboptimal.

A local bounded gap search at cutoff 320 found gap about 1.479705 with discretized value 0.061955534347. We retain the simpler exact gap 3/2 for the reproducible explicit-state candidate.

## Precisely defined model
Use hbar=1 and particle mass=1/2. Momentum wavefunctions live in L2([0,infinity),dp). The intervals are

[-g/2-1,-g/2] and [g/2,g/2+1].

For a normalized state psi, the objective is the sum of the two increases in probability on x<0. The real symmetric momentum kernel is

K_g(p,q) = -(p+q)/pi * sinc((p^2-q^2)/(2*pi)) * cos((g+1)*(p^2-q^2)/2),

where numpy's normalized sinc is used; on the diagonal K_g(p,p)=-2p/pi. This follows directly from Eq. 2.13/2.25 of Fewster–Kirk-Karakaya. It is not an instantaneous current, measurement-conditioned process, or information-backflow quantity.

Two observation durations remain fixed at one while g varies. Total elapsed span g+2 changes. For unbounded momentum, uniform time scaling is a unitary equivalence and hence has no effect on the optimization over all states. At fixed momentum cutoff, scaling time changes the corresponding dimensionless momentum support, so comparisons at fixed span must be checked separately. At cutoff40 with total span fixed to3, gap1 gave0.0600318264125 and gap1.5 gave0.0602714605751; thus the finite-cutoff advantage survives this alternative constraint too.

## Sources and status check
- Fewster and Kirk-Karakaya, *Repeated quantum backflow and overflow*, Proceedings of the Royal Society A 481 (2025), 20250577: https://doi.org/10.1098/rspa.2025.0577
- Searchable paper: https://arxiv.org/html/2505.13184v1
- Authors' spectral data and programs: https://github.com/hkk506/Repeated-quantum-backflow-and-quantum-overflow/

The paper defines arbitrary interval geometries analytically, but its numerical calculations in Section5 concern equal lengths and equal spacing. Table5.5 supplies the comparison estimates. The global two-interval constant is a different optimization. Targeted searches for multiple backflow, variable spacing and interval optimization did not establish a prior matching result; absence from searches is not proof of novelty. The paper and author's subsequent thesis require full bibliography/citation review before any originality claim.

## Numerical evidence
Momentum cutoff L; duration1; gap1.5. Dense Gauss–Legendre and independent composite-energy FFT implementations agree at overlapping cutoffs.

| L | Approximate value | Cross-check |
|---|---:|---|
|40|0.060411762642|dense n2400/3600 difference about4e-12; FFT agrees|
|60|0.060999783988|dense n5000/6500 difference below1e-13|
|80|0.061293568960|dense n8500/10000 difference1.3e-11; FFT agrees|
|120|0.061587474527|8/12 nodes per energy panel difference1.4e-12|
|160|0.061734521496|8/12 nodes per panel difference1.4e-12|
|200|0.061822753648|8/12 nodes per panel difference1.4e-12|
|320|0.061955116524|8/12 nodes per panel difference1.4e-12|

At L80, gap1 yields0.060940079675. At L320, gap1 yields0.061621611178. Thus the gap advantage persists with increasing support, rather than appearing only at one cutoff. No limiting value is inferred from this table.

The gap search is bounded and local, not a global certificate. L40/80 searches exhausted14 evaluations and should be read as good tested candidates, not converged optima. The L320 search converged under the specified scalar optimizer's stopping rule. See gap_optima.json and optimize_stdout.txt.

## Fast solver
Write x=p^2 in the tail. The unitarily transformed state is phi(x)=psi(sqrt(x))/sqrt(2sqrt(x)). The energy kernel decomposes into two diagonally weighted convolution kernels. A uniform energy-panel Gaussian rule therefore yields block Toeplitz matrices, applied using FFTs. A separate momentum-coordinate head panel [0,sqrt(2)] handles the integrable energy-coordinate endpoint singularity.

Tail energy panel width2, 12 Gaussian nodes/panel, 32 head nodes, L320 gives614420 total nodes. The eigensolve took about4.4 seconds in the recorded environment; dense L80/n10000 took about6.8 seconds. Timings are machine-specific. Residuals of the discrete eigenproblem are around1e-14 or smaller and do not bound discretization error.

## Actual explicit state
The final state is **defined by the binary-exact coefficients** in explicit_state_L320_g1.5.npz, not by an informal continuum interpretation of the eigenvector.

Head: head_coeff contains32 coefficients in the orthonormal Legendre basis on p∈[0,sqrt(2)].

Tail: tail_coeff has shape(12,51199). Column j-1 represents phi(x) on x∈[2j,2j+2], j=1,...,51199, in its degree≤11 orthonormal Legendre basis. The basis on [a,a+d] is sqrt((2l+1)/d) P_l(2(x-a)/d-1). Reconstruct physical psi(p)=sqrt(2p)*phi(p^2). State is zero for p>320 and for p<0.

Divide the state by sqrt(S), where S is the exact sum of squares of all stored binary64 coefficients:

S = 26328072917139387318411538108214910898348849024565439159119001729 / 2^214.

This makes the continuum state normalized by definition. It has finite momentum support, hence finite energy. Piecewise polynomial joins are not asserted to be experimentally convenient.

SHA-256 of coefficient archive:
23c0a9394e820932e48be943ad90d3a87bab6faba6b651e004b99aa8c4460aa9

## Independent integration and certification boundary
The state selected at12 tail nodes/panel was held fixed and re-integrated at24 and48 tail nodes/panel, with64 head nodes. These were new quadrature evaluations, not new eigenvector optimizations. They agreed to about4e-16. The coefficient-defined state also agrees at numerical precision.

An independent analytic argument bounds the **exact-arithmetic quadrature truncation** for this finite-support polynomial state at48/64 nodes by about2.4e-14. See mixed_panel_certificate_bound.md. There is no uncomputed momentum tail for this particular state.

However, the current executable uses floating-point Gaussian nodes, special functions and FFTs without interval enclosures or an implementation-specific forward-error certificate. Quadrature convergence and tiny eigensolver residuals do not close that gap. Accordingly the reported value remains a strongly cross-checked numerical evaluation. An end-to-end rounding certificate, and separate novelty review, are still required before calling it a rigorous new lower bound.

## Reproduction
Python3 with NumPy and SciPy. OPENBLAS_NUM_THREADS=1 was used.

- search.py: dense solver; convergence and matched-span tests. Outputs search_results.json.
- fft_solver.py: composite-energy FFT solver and fixed-state evaluator. Outputs fft_results.jsonl.
- extend.py: larger cutoff and gap grid.
- optimize_gap.py: local bounded gap search.
- explicit_state.py: converts the saved nodal state to binary-exact coefficient state and computes its squared norm as an exact rational.
- validate_explicit.py: independently re-integrates the exact-coefficient candidate at24/48 tail nodes.

Running validate_explicit.py requires several GB of RAM for its48-node evaluation. It takes tens of seconds on the tested machine. The24-node evaluation is cheaper. Existing JSON/JSONL and stdout records preserve the completed results and runtimes.

## What has and has not been achieved
Achieved: a concrete finite-support candidate exceeding a published equal-spacing numerical benchmark, cross-checked discretizations, explicit normalized state, and an analytic quadrature-error route.

Not achieved: the exact global two-interval constant, a rigorous upper bound for equal spacing, end-to-end interval certification, confirmation of novelty, or experimental validation. This is a credible first research attempt, not a solved open problem.
