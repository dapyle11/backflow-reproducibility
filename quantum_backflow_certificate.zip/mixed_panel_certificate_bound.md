# Mixed momentum/energy-panel quadrature truncation certificate

This derivation supports fft_solver.py's explicitly lifted state. It does not certify floating-point rounding or the eigensolver, which is only used to choose the state.

## State
Head coordinate p in [0,sqrt(h)]: polynomial f_0(p) degree nh-1.
Tail coordinate x=p^2 on panels [jh,(j+1)h], j>=1: polynomial f_j(x) degree k-1 representing phi(x)=psi(sqrt(x))/sqrt(2sqrt(x)).
State is zero beyond cutoff L. The sum of polynomial squared norms in these separate coordinates is its physical norm. Original Gaussian samples give exact norm in exact arithmetic. For a reproducible exact state, use specified binary-exact Legendre coefficients on each panel and normalize by their exactly defined squared sum.

## General block quadrature bound
Panel i has coordinate length d_i, polynomial degree n_i-1, local squared norm eta_i^2, with sum eta_i^2=1. Use m_i-point Gauss on panel i, Bernstein ellipse parameter rho>1. Suppose every mixed-coordinate transformed kernel is bounded by C when either argument is on its own panel ellipse and the other argument is real.

Set
A=sqrt(sum_i n_i^2 d_i rho^[2(n_i-1-2m_i)]),
B=sqrt(sum_i n_i^2 d_i).
Then absolute error in the complete double-integral Rayleigh numerator is <=8 C A B/(1-rho^-1).

Sharper bounds replace A and B by sum_i n_i sqrt(d_i) eta_i rho^(n_i-1-2m_i) and sum_i n_i sqrt(d_i) eta_i, respectively.

Proof: polynomial bound on ellipse is n_i eta_i rho^(n_i-1)/sqrt(d_i), and on its real interval n_i eta_i/sqrt(d_i). Apply the Chebyshev-tail Gaussian rule bound 4d_i M rho^-2m_i/(1-rho^-1) to each block in either variable; the other integral or positive quadrature has weight d_j. Sum blocks, then Cauchy-Schwarz against sum eta_i^2=1. See polynomial_certificate_bound.md for the elementary Chebyshev-tail proof.

## Explicit uniform kernel bound for h=2 and rho=2
The original momentum kernel is K(p,q)=-(p+q)/(2pi) integral_intervals exp(it(p^2-q^2))dt.
Under any coordinate change p=p(z), multiply by sqrt(J(z)J(y)), J=dp/dz. Head J=1; tail J=1/(2sqrt(z)).

On a tail energy-panel ellipse, Re z >= jh-h/8 >=1.75, so |J|<=1/(2sqrt(1.75))<1. Positive-real-axis fractional-power branches are analytic on all these ellipses. Also |p|<=sqrt(L^2+0.25), and |Im(p^2)|=|Im z|<=0.75.
On the head momentum ellipse, |p|<=1.125sqrt(2), |Im(p^2)|<=2*(1.125)*(.375)*2=1.6875.
For L>=2, either head or tail thus obeys |p|<=sqrt(L^2+0.25), all Jacobian magnitude factors <=1, and |Im(p^2)|<=1.6875. The other physical momentum q is real and <=L.

Therefore the following conservative C works:
C=[2sqrt(L^2+0.25)/pi] exp[(1+g/2)*1.6875].

There are J=L^2/2-1 tail panels when L^2/2 is integral. For nh32,k12, choose m_head64, m_tail48. Then
B^2=32^2 sqrt(2)+J*12^2*2,
A^2=32^2 sqrt(2)*2^-194 + J*12^2*2*2^-170.

At g1.5 this gives the truncation errors computed below. These are exact-arithmetic analytic bounds, not interval-enclosed numerical evaluations. A certificate must additionally enclose node/weight generation, coefficient evaluation, kernel evaluation and sums/FFTs. Validation at 48 nodes per tail panel can be expensive; FFT block implementation must avoid retaining every giant transform simultaneously.

L=200: bound 5.81384e-15.

L=240: bound 1.00461e-14.

L=280: bound 1.59526e-14.

L=320: bound 2.38123e-14.
